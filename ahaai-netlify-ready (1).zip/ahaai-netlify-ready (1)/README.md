# AHA.AI (Static Site)
Implements the exact style spec you provided: gradients, glass nav, shimmer, hover underlines, card lift, market glow, CTA shine, scroll-triggered fades, smooth scrolling, and dynamic navbar.

## Deploy (Netlify, no build step)
1. Zip contents and drag‑drop into Netlify: **Add new site → Deploy manually**.
2. Or commit to a repo and connect via **Netlify → Connect to Git**.

Generated on 2025-09-03.
