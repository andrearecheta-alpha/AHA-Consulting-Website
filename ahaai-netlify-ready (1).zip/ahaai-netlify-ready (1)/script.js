// Year in footer
document.getElementById('year').textContent = new Date().getFullYear();

// Dynamic navbar: toggle .scrolled
(function(){
  const nav = document.getElementById('navbar');
  function onScroll(){
    if(window.scrollY > 10){
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();
})();

// Intersection Observer for scroll animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};
const observer = new IntersectionObserver((entries)=>{
  entries.forEach(entry => {
    if(entry.isIntersecting){ entry.target.classList.add('visible'); }
  });
}, observerOptions);
document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));
